<?xml version="1.0" encoding="UTF-8"?>
<tileset name="lec6-5" tilewidth="64" tileheight="128" tilecount="64" columns="8">
 <image source="lec6-5.png" trans="ff00ff" width="512" height="1024"/>
 <tile id="6">
  <properties>
   <property name="h" type="float" value="58"/>
   <property name="isPlayer" type="bool" value="true"/>
   <property name="sprite" value="sprites/lec6-player.png"/>
   <property name="w" type="float" value="60"/>
   <property name="x" type="float" value="0"/>
   <property name="y" type="float" value="50"/>
  </properties>
 </tile>
 <tile id="44">
  <properties>
   <property name="h" type="float" value="78"/>
   <property name="isPlayer" type="bool" value="true"/>
   <property name="sprite" value="sprites/lec4-player.png"/>
   <property name="w" type="float" value="60"/>
   <property name="x" type="float" value="0"/>
   <property name="y" type="float" value="50"/>
  </properties>
 </tile>
</tileset>
